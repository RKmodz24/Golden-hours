export const firebaseConfig = {
  "projectId": "studio-8679056346-13abe",
  "appId": "1:259266448690:web:e778bdc13df3a9254c5b2b",
  "apiKey": "AIzaSyC9hSEHxbQq3Sy3rLyHeldk1CLePVFajk4",
  "authDomain": "studio-8679056346-13abe.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "259266448690"
};
