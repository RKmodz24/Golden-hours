import { config } from 'dotenv';
config();

import '@/ai/flows/intelligent-ad-serving.ts';
